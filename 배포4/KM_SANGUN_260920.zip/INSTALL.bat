@echo off
chcp 65001 >nul
title KM SANGUN INSTALL
cd /d "%~dp0"
python "%~dp0install.py" 2>nul
if errorlevel 9009 py "%~dp0install.py"
if errorlevel 1 (
  echo.
  echo Python not found. Please capture this window and show Claude.
  pause
)
